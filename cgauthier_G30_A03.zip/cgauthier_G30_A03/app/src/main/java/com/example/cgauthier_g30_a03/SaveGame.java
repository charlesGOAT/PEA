package com.example.cgauthier_g30_a03;
import com.example.cgauthier_g30_a03.DoublyLinkedList;
import com.example.cgauthier_g30_a03.Player;

import java.io.*;
public class SaveGame implements Serializable{//SaveGame Author, Charles-Etienne Gauthier

	//singleton
	static SaveGame save = new SaveGame();
	private SaveGame(){

	}
	public static SaveGame getInstance(){
		return save;
	}

public void saveAllPlayers(DoublyLinkedList<Player> doublyLinkedList,File c) {//saveAllPlayers(DoublyLinkedList<Player> doublyLinkedList)
	try {//try
		File theFile= new File(c,"scoreBoard.ser");
		FileOutputStream outStream = new FileOutputStream(theFile);
		ObjectOutputStream objectOutputFile = new ObjectOutputStream(outStream);
		objectOutputFile.writeObject(doublyLinkedList);
		outStream.close();
		objectOutputFile.close();
	}//try 
	catch (Exception e) {//catch
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	//catch
	
	
}//saveAllPlayers(DoublyLinkedList<Player> doublyLinkedList)


}//SaveGame
