package com.example.cgauthier_g30_a03;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
//this is the mainActivity where everything shows up. Author, Charles-Etienne Gauthier

public class MainActivity extends AppCompatActivity implements View.OnClickListener {//MainActivity
static MainActivity main = new MainActivity();
static boolean isGamePlayed = false;

    static File fileDir;
public static MainActivity getInstance(){
    return main;
}
    DictionaryReader read =  DictionaryReader.getInstance();
    Game game = new Game();
    ScoreBoard score = ScoreBoard.getInstance();
    SaveGame save =  SaveGame.getInstance();


static boolean hideOrReveal = false;

    public void hide(){//hide
        findViewById(R.id.textView).setVisibility(View.GONE);
        findViewById(R.id.tries).setVisibility(View.GONE);
        findViewById(R.id.imageView).setVisibility(View.GONE);
        findViewById(R.id.myHint).setVisibility(View.GONE);
        findViewById(R.id.table).setVisibility(View.GONE);
        findViewById(R.id.unknownWord).setVisibility(View.GONE);

    }//hide
    public void reveal(){//reveal
        findViewById(R.id.textView).setVisibility(View.VISIBLE);
        findViewById(R.id.tries).setVisibility(View.VISIBLE);
        findViewById(R.id.imageView).setVisibility(View.VISIBLE);

        findViewById(R.id.myHint).setVisibility(View.VISIBLE);



    }//reveal

    protected void onCreate(Bundle savedInstanceState) {//onCreate

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.textFieldName).setOnClickListener(this);
        findViewById(R.id.score).setOnClickListener(this);
        findViewById(R.id.myHint).setOnClickListener(this);
        findViewById(R.id.help).setOnClickListener(this);
        fileDir = getFilesDir();
        if (!hideOrReveal) {//if
            hide();
        }//if
        else {//else
            reveal();
            startGame();

        }//else


        try {//try
            InputStream getDictionary = getAssets().open("dictionary.txt");
            read.readFromFile(getDictionary);
        }//try
        catch (IOException e) {//catch
            e.printStackTrace();
        }//catch

    }//onCreate
public void generateBtn(){//generateBtn
    ViewGroup buttonContainer1 =findViewById(R.id.buttonContainer1);
    ViewGroup buttonContainer2 =findViewById(R.id.buttonContainer2);
    ViewGroup buttonContainer3 =findViewById(R.id.buttonContainer3);
    ViewGroup buttonContainer4 =findViewById(R.id.buttonContainer4);
    ViewGroup buttonContainer5 =findViewById(R.id.buttonContainer5);
    ViewGroup buttonContainer6 =findViewById(R.id.buttonContainer6);
    ViewGroup buttonContainer7 =findViewById(R.id.buttonContainer7);
    for(char c = 'a'; c <= 'z'; ++c){//for
        Button button = new Button(this);
        button.setOnClickListener(this);
        button.setText( c+" ");
        button.setTextSize(10f);
        button.setId(c);
        button.setHeight(1);
        button.setWidth(1);
        if(c>='a'&&c<='d')
            buttonContainer1.addView(button);
        else if(c>'d'&&c<='h')
            buttonContainer2.addView(button);
        else if(c>'h'&&c<='l')
            buttonContainer3.addView(button);
        else if(c>'l'&&c<='p')
            buttonContainer4.addView(button);
        else if(c>'p'&&c<='t')
            buttonContainer5.addView(button);
        else if(c>'t'&&c<='x')
            buttonContainer6.addView(button);
        else if(c>'x'&&c<='z')
            buttonContainer7.addView(button);
    }//for
}//generateBtn

    public void startFirstTime(String name){//startFirstTime
        Player thePlayer = new Player(name, 0, 0, read.getAllWords());
        score.getDifferentPlayers().add(thePlayer);
        ScoreBoard.setSelectedPlayer(thePlayer);

        save.saveAllPlayers(score.getDifferentPlayers(),fileDir);
    }//startFirstTime
    @Override
    public void onClick(View v) {//onClick
        final int id= v.getId();
        if(id==R.id.textFieldName){//if
            Intent i = new Intent(this, PlayerLogin.class);
            startActivity(i);

        }//if
else if(id==R.id.score){//if
    
    Intent i = new Intent(this, Score.class);
    startActivity(i);
}//if
else if(id==R.id.help){
    AlertDialog.Builder myAlert = new AlertDialog.Builder(MainActivity.this);
myAlert.setTitle("Help");
    myAlert.setMessage("Hello and welcome to Charles' game of hangman!\n " +
            "To start, press on play and select either and existing player or a previous one\n" +
            "You have six tries. A hint takes on life but in exchange a letter. Good luck!");

myAlert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
    @Override
    public void onClick(DialogInterface dialog, int which) {
        Toast.makeText(MainActivity.this, "good luck!", Toast.LENGTH_SHORT).show();
    }
});



myAlert.show();
}

      else if(id==R.id.myHint){//myHint

            TextView lblUnknownWord = findViewById(R.id.unknownWord);
            TextView lblTriesRemaining = findViewById(R.id.tries);
            if (game.getTriesRemaining() == 1) {//if
                Context context = getApplicationContext();
                Toast.makeText(context,"Cannot request for a hint when only one try remaining",Toast.LENGTH_LONG).show();
            }//if
            else if (game.getWord().getLength()==1) {//else if
                Context context = getApplicationContext();
                Toast.makeText(context,"Cannot select hint when there is only one letter left",Toast.LENGTH_LONG).show();
            }//else if
            else {//else

        setImage(game.getTriesRemaining()-1);
                game.getHint();
                game.setNumHint(game.getNumHint()+1);
                ViewGroup buttonContainer1 =findViewById(R.id.buttonContainer1);
                for(int i = 0; i<buttonContainer1.getChildCount();++i){//for
                    Button btn = (Button)buttonContainer1.getChildAt(i);
                    if(game.getRandLet()==btn.getText().charAt(0)){//if
                        btn.setEnabled(false);
                    }//if
                }//for
                ViewGroup buttonContainer2 =findViewById(R.id.buttonContainer2);
                for(int i = 0; i<buttonContainer2.getChildCount();++i){//for
                    Button btn = (Button)buttonContainer2.getChildAt(i);
                    if(game.getRandLet()==btn.getText().charAt(0)){//if
                        btn.setEnabled(false);
                    }//if
                }//for
                ViewGroup buttonContainer3 =findViewById(R.id.buttonContainer3);
                for(int i = 0; i<buttonContainer3.getChildCount();++i){//for
                    Button btn = (Button)buttonContainer3.getChildAt(i);
                    if(game.getRandLet()==btn.getText().charAt(0)){//if
                        btn.setEnabled(false);
                    }//if
                }//for
                ViewGroup buttonContainer4 =findViewById(R.id.buttonContainer4);
                for(int i = 0; i<buttonContainer4.getChildCount();++i){//for
                    Button btn = (Button)buttonContainer4.getChildAt(i);
                    if(game.getRandLet()==btn.getText().charAt(0)){//if
                        btn.setEnabled(false);
                    }//if
                }//for
                ViewGroup buttonContainer5 =findViewById(R.id.buttonContainer5);
                for(int i = 0; i<buttonContainer5.getChildCount();++i){//for
                    Button btn = (Button)buttonContainer5.getChildAt(i);
                    if(game.getRandLet()==btn.getText().charAt(0)){
                        btn.setEnabled(false);
                    }
                }//for
                ViewGroup buttonContainer6 =findViewById(R.id.buttonContainer6);
                for(int i = 0; i<buttonContainer6.getChildCount();++i){//for
                    Button btn = (Button)buttonContainer6.getChildAt(i);
                    if(game.getRandLet()==btn.getText().charAt(0)){
                        btn.setEnabled(false);
                    }
                }//for
                ViewGroup buttonContainer7 =findViewById(R.id.buttonContainer7);
                for(int i = 0; i<buttonContainer7.getChildCount();++i){//for
                    Button btn = (Button)buttonContainer7.getChildAt(i);
                    if(game.getRandLet()==btn.getText().charAt(0)){
                        btn.setEnabled(false);
                    }
                }//for

                lblTriesRemaining.setText("Tries Remaining:" + (game.getTriesRemaining()));
                lblUnknownWord.setText(game.getUnknownWord());



            }//else
    if(hideOrReveal){//if
    for (int i = 0; i < score.getDifferentPlayers().getLength(); i++) {//for
        if (score.getDifferentPlayers().getElementAt(i).getName() == score.getSelectedPlayer().getName()
                && score.getSelectedPlayer() != null) {//if
            score.getDifferentPlayers().find(i)
                    .setElement(new Player(score.getSelectedPlayer().getName(),
                            score.getSelectedPlayer().getNumberGamesPlayed(),
                            score.getSelectedPlayer().getNumberGamesWon(), game.getLettersGuessed(),
                            score.getSelectedPlayer().getWordArray(), game.getListCounter(),game.getNumHint()));
            save.saveAllPlayers(score.getDifferentPlayers(),getFilesDir());
        }//if
        }//for
    }//if
        }//myHint

//
else{//else
    Button btn = (Button) v;
    btn.setEnabled(false);
            TextView lblUnknownWord = findViewById(R.id.unknownWord);
  TextView lblTriesRemaining = findViewById(R.id.tries);
            lblTriesRemaining.setText("Tries Remaining:" + game.getTriesRemaining());

            if (game.selectLetter(btn.getText().charAt(0), false)) {//if
            lblUnknownWord.setText(game.getUnknownWord());
            if (game.isWinOrLost()) {//if
                score.getSelectedPlayer()
                        .setNumberGamesPlayed(score.getSelectedPlayer().getNumberGamesPlayed() + 1);
                score.getSelectedPlayer().setListCounter(score.getSelectedPlayer().getListCounter() + 1);

                if (game.getWinOrLost()) {//if
                    score.getSelectedPlayer().setLettersGuessed(null);
                    score.getSelectedPlayer()
                            .setNumberGamesWon(score.getSelectedPlayer().getNumberGamesWon() + 1);
                    score.getSelectedPlayer().setListCounter(score.getSelectedPlayer().getListCounter() + 1);
                    Context context = getApplicationContext();
                    Toast.makeText(context,"You won this game!",Toast.LENGTH_LONG).show();
                    game.setNumHint(0);
                    startGame();
                }//if

            }//if

        }//if
            else {//else
            lblTriesRemaining.setText("Tries Remaining:" + game.getTriesRemaining());
            setImage(game.getTriesRemaining()-1);
//fix tries remaining bug and the button setEnable glitch
            if (game.isWinOrLost()) {//if

                if (!game.getWinOrLost()) {//if

                    score.getSelectedPlayer()
                            .setNumberGamesPlayed(score.getSelectedPlayer().getNumberGamesPlayed() + 1);
                    score.getSelectedPlayer().setListCounter(score.getSelectedPlayer().getListCounter() + 1);
                    lblUnknownWord.setText(game.getUnknownWord());
                    score.getSelectedPlayer().setLettersGuessed(null);
                    Context context = getApplicationContext();
                    Toast.makeText(context,"You lost the game... RIP :(",Toast.LENGTH_LONG).show();
                    game.setNumHint(0);
                    startGame();
                }//if
            }//if
        }//else

            for (int i = 0; i < score.getDifferentPlayers().getLength(); i++) {//for
                if (score.getDifferentPlayers().getElementAt(i).getName() == score.getSelectedPlayer().getName()
                        && score.getSelectedPlayer() != null) {//if
                    score.getDifferentPlayers().find(i)
                            .setElement(new Player(score.getSelectedPlayer().getName(),
                                    score.getSelectedPlayer().getNumberGamesPlayed(),
                                    score.getSelectedPlayer().getNumberGamesWon(), game.getLettersGuessed(),
                                    score.getSelectedPlayer().getWordArray(), game.getListCounter(), game.getNumHint()));
                    save.saveAllPlayers(score.getDifferentPlayers(),getFilesDir());

            }//if
        }//for
}//else






}//onClick




    public void startGame(){//startGame
        ViewGroup buttonContainer1 =findViewById(R.id.buttonContainer1);
        ViewGroup buttonContainer2 =findViewById(R.id.buttonContainer2);
        ViewGroup buttonContainer3 =findViewById(R.id.buttonContainer3);
        ViewGroup buttonContainer4 =findViewById(R.id.buttonContainer4);
        ViewGroup buttonContainer5 =findViewById(R.id.buttonContainer5);
        ViewGroup buttonContainer6 =findViewById(R.id.buttonContainer6);
        ViewGroup buttonContainer7 =findViewById(R.id.buttonContainer7);

        buttonContainer1.removeAllViews();
        buttonContainer2.removeAllViews();
        buttonContainer3.removeAllViews();
        buttonContainer4.removeAllViews();
        buttonContainer5.removeAllViews();
        buttonContainer6.removeAllViews();
        buttonContainer7.removeAllViews();
        generateBtn();
        try {


        game.setTriesRemaining(6);
        game.setNumHint(score.getSelectedPlayer().getNumHint());

        TextView playerName = findViewById(R.id.textView);
        playerName.setText(score.getSelectedPlayer().getName());
        TextView lblUnknownWord = findViewById(R.id.unknownWord);
        TextView triesRemaining = findViewById(R.id.tries);
        game.setListCounter(score.getSelectedPlayer().getListCounter());
        game.setWord(score.getSelectedPlayer().getWordArray());
            if(game.getWord().getLength()==0)
                throw new Exception();
        if (score.getSelectedPlayer().getLettersGuessed() != null) {//if
            game.setLettersGuessed(score.getSelectedPlayer().getLettersGuessed());
            int size = game.getLettersGuessed().getLength();
            for (int i = 0; i < size; ++i) {//for
                game.selectLetter(game.getLettersGuessed().getElementAt(i), true);


            }//for
for(int x=0; x<score.getSelectedPlayer().getLettersGuessed().getLength();x++){//for


    for(int i = 0; i<buttonContainer1.getChildCount();++i){//for
        Button btn = (Button)buttonContainer1.getChildAt(i);
        if(score.getSelectedPlayer().getLettersGuessed().getElementAt(x)==btn.getText().charAt(0)){//if
            btn.setEnabled(false);
        }//if
    }//for

    for(int i = 0; i<buttonContainer2.getChildCount();++i){//for
        Button btn = (Button)buttonContainer2.getChildAt(i);
        if(score.getSelectedPlayer().getLettersGuessed().getElementAt(x)==btn.getText().charAt(0)){//if
            btn.setEnabled(false);
        }//if
    }//for

    for(int i = 0; i<buttonContainer3.getChildCount();++i){//for
        Button btn = (Button)buttonContainer3.getChildAt(i);
        if(score.getSelectedPlayer().getLettersGuessed().getElementAt(x)==btn.getText().charAt(0)){//if
            btn.setEnabled(false);
        }//if
    }//for

    for(int i = 0; i<buttonContainer4.getChildCount();++i){//for
        Button btn = (Button)buttonContainer4.getChildAt(i);
        if(score.getSelectedPlayer().getLettersGuessed().getElementAt(x)==btn.getText().charAt(0)){//if
            btn.setEnabled(false);
        }//if
    }//for

    for(int i = 0; i<buttonContainer5.getChildCount();++i){//for
        Button btn = (Button)buttonContainer5.getChildAt(i);
        if(score.getSelectedPlayer().getLettersGuessed().getElementAt(x)==btn.getText().charAt(0)){//if
            btn.setEnabled(false);
        }//if
    }//for

    for(int i = 0; i<buttonContainer6.getChildCount();++i){//for
        Button btn = (Button)buttonContainer6.getChildAt(i);
        if(score.getSelectedPlayer().getLettersGuessed().getElementAt(x)==btn.getText().charAt(0)){//if
            btn.setEnabled(false);
        }//if
    }//for

    for(int i = 0; i<buttonContainer7.getChildCount();++i){//for
        Button btn = (Button)buttonContainer7.getChildAt(i);
        if(score.getSelectedPlayer().getLettersGuessed().getElementAt(x)==btn.getText().charAt(0)){//if
            btn.setEnabled(false);
        }//if
    }//for

}//for



        }//if
        game.setTriesRemaining(game.getTriesRemaining()-game.getNumHint());

      triesRemaining.setText("Tries Remaining:"+ game.getTriesRemaining());
        setImage(game.getTriesRemaining()-1);
        lblUnknownWord.setText(game.getUnknownWord());}

        catch (Exception e){
            Log.e("Exception",e.toString());
            hideOrReveal=false;
            hide();
            Context context = getApplicationContext();
            Toast.makeText(context, "No words in array",Toast.LENGTH_SHORT).show();


        }
    }//startGame
    public void setImage(int triesRemaining) {//public void
        if (triesRemaining > 0) {//if
            String images[] = {"hangman6.gif", "hangman5.gif", "hangman4.gif", "hangman3.gif", "hangman2.gif", "hangman1.gif"};
            ImageView image = (ImageView) findViewById(R.id.imageView);
            try (InputStream stream = getAssets().open(images[triesRemaining])) {//try
                Drawable d = Drawable.createFromStream(stream, null);
                image.setImageDrawable(d);
            }//try
            catch (IOException e) {//catch
                e.printStackTrace();
            }//catch
        }//if
    }//setImage

}//MainActivity
