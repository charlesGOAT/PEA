package com.example.cgauthier_g30_a03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

//This is to show the store. Author, Charles-Etienne Gauthier
public class Score extends AppCompatActivity {//Score
ScoreBoard score = ScoreBoard.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {//onCreate
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoreboard);

        try {//try
            loadGame();
        }//try
        catch (Exception e) {//Exception
            e.printStackTrace();
        }//Exception

        LinearLayout scrollView = (LinearLayout) findViewById(R.id.linearLayout);
for(int i =0; i<score.getDifferentPlayers().getLength(); ++i){//for
    TextView text = new TextView(this);
String getPlayer = "          "+score.getDifferentPlayers().getElementAt(i).getName();
    scrollView.addView(text);
    text.setText(String.format("%-45s%-35s%-35s",getPlayer,score.getDifferentPlayers().getElementAt(i).getNumberGamesWon(),score.getDifferentPlayers().getElementAt(i).getNumberGamesPlayed()));

    System.out.println(text.getText());
}//for
    }//onCreate
    public void loadGame() throws Exception {//loadGame()

        try {//try
            File fileDir = getFilesDir();
            File file = new File(fileDir, "scoreBoard.ser");
            FileInputStream fileIn = new FileInputStream(file);
            ObjectInputStream in = new ObjectInputStream(fileIn);

            score.setDifferentPlayers((DoublyLinkedList)in.readObject());

            in.close();
            fileIn.close();


        }//try
        catch(Exception e){//catch
            e.printStackTrace();
        }//catch
    }//loadGame()
}//Score