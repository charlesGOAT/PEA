package com.example.cgauthier_g30_a03;
import java.util.regex.*;  
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class DictionaryReader implements Serializable{//DictionaryReader is used to read the dictionary Author, Charles-Etienne Gauthier

	//did a singleton
	static DictionaryReader dictionaryReader = new DictionaryReader();
	private DictionaryReader(){

	}

	public static DictionaryReader getInstance(){//getInstance

		return dictionaryReader;
	}//getInstance


	private String word;

	private SinglyLinkedList<String> allWords = new SinglyLinkedList();
	
	
	public boolean readFromFile(InputStream c) throws IOException {// readFromFile
		try {// try


			Scanner fileReader = new Scanner(c);





			while (fileReader.hasNext()) {// while
				String line = fileReader.nextLine();
				while (line.trim().isEmpty()) {// while

					line = fileReader.nextLine();
				} // while
				 // catch FileNotFoundException
				 int sizeMinusOne = allWords.getLength()-1;
                 if(allWords.getLength()==0) {//if
                                 sizeMinusOne=0;
                 }//if
                 int randomizer = (int)Math.floor(Math.random()*(sizeMinusOne));
                 allWords.add(line,randomizer);

				
				
	}//while
			
			int i =0;
			while(i<allWords.getLength()) {//while
				if(!verifyWord(allWords.getElementAt(i))) {//if
					allWords.remove(i);
				i=0;
				}//if
				else {//else
					++i;
				}//else
				
				
			}//while
return true;
}//try
		catch(Exception e) {//catch
	System.out.print(e);
	return false;
}//catch
		}//readFromFile
	public String getWord() {//getWord
		return word;
	}//getWord
	public SinglyLinkedList<String> getAllWords() {//getAllWords()
		return allWords;
	}//getAllWords()

	public boolean verifyWord(String word) {//verifyWord
		return Pattern.matches("^[a-zA-Z0-9\\.\\,\\-\\ \\$\\#\\!\\?]+$", word)&&word.trim().length()>6&&word.length()<25;
		}//verifyWord

}//DictionaryReader is used to read the dictionary
