package com.example.cgauthier_g30_a03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class PlayerLogin extends AppCompatActivity implements  View.OnClickListener {//PlayerLogin


    String[] items;
    SaveGame save =  SaveGame.getInstance();
    ScoreBoard score =  ScoreBoard.getInstance();
    MainActivity mainActivity = MainActivity.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {//onCreate
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_login);
        Spinner dropdown = findViewById(R.id.comboBoxExistingPlayer);
        findViewById(R.id.play).setOnClickListener(this);
        try {//try
            loadGame();
            if(score.getDifferentPlayers().getLength()!=0)
            items = new String[score.getDifferentPlayers().getLength()+1];
            else items = new String[]{""};
        }//try
        catch (Exception e) {//catch
        }//catch
items[0]="";
        for (int i = 0; i < score.getDifferentPlayers().getLength(); ++i) {//for
            items[i+1] = score.getDifferentPlayers().getElementAt(i).getName();

        }//for

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

    }//onCreate
            public void loadGame() throws Exception {//loadGame()
                File fileDir = getFilesDir();
                File file = new File(fileDir, "scoreBoard.ser");
                try {//try
                    FileInputStream fileIn = new FileInputStream(file);
                    ObjectInputStream in = new ObjectInputStream(fileIn);

                   score.setDifferentPlayers((DoublyLinkedList)in.readObject());

                    in.close();
                    fileIn.close();


                }//try
                catch(Exception e){//catch
                    e.printStackTrace();
                }//catch
            	}//loadGame()

    @Override
    public void onClick(View v) {//onClick
        final int id = v.getId();
        boolean contains = false;
        TextView textFieldName = findViewById(R.id.textFieldName);
        Spinner comboBoxExistingPlayer = findViewById(R.id.comboBoxExistingPlayer);
        if(id==R.id.play){//play
            for (int i = 1; i<items.length;++i){//for
                if (textFieldName.getText().toString().equals(items[i])){//if
                    contains=true;
                }//if
            }//for
            if(contains){//if
                Context context = getApplicationContext();
                Toast.makeText(context, "An existing player has the same name as you.", Toast.LENGTH_LONG).show();
            }//if
        else if (textFieldName.getText().toString().replace(" ", "").equals("") && comboBoxExistingPlayer.getSelectedItem().equals("")) {//else if
            Context context = getApplicationContext();
            Toast.makeText(context, "You must enter a valid name for the player or select an existing one", Toast.LENGTH_LONG).show();

        }//else if
        else if (textFieldName.getText().toString().replace(" ", "").length() > 10) {//else if
            Context context = getApplicationContext();
            Toast.makeText(context, "Player name is too long. Please enter a name that is less than 10 characters", Toast.LENGTH_LONG).show();

        }//else if

        else if (!comboBoxExistingPlayer.getSelectedItem().toString().equals("")
                && !textFieldName.getText().toString().replace(" ", "").equals("")) {//else if
            Context context = getApplicationContext();
            Toast.makeText(context, "Both existing an new player cannot be selected at the same time", Toast.LENGTH_LONG).show();
        }//else if

        else if (!comboBoxExistingPlayer.getSelectedItem().toString().equals("")) {//else if
            for (int i = 0; i < score.getDifferentPlayers().getLength(); ++i) {//for
                if (comboBoxExistingPlayer.getSelectedItem() == score.getDifferentPlayers().getElementAt(i)
                        .getName()) {//if
                    ScoreBoard.setSelectedPlayer(score.getDifferentPlayers().getElementAt(i));

                }//if


            }//for
            MainActivity.hideOrReveal = true;
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        }//else if
        else {//else


                Intent i = new Intent(this, MainActivity.class);
                startActivity(i);
                MainActivity.getInstance().startFirstTime(textFieldName.getText().toString());
                MainActivity.hideOrReveal = true;
            }//else



        }//play


    }//onClick
}//PlayerLogin
